# Versiones Hydra Traffic Lab

Este archivo separa la historia general del producto de las revisiones practicas de la rama moderna.

## Versiones generales

- V1: fases basicas.
- V2: lazos, camara virtual y colas.
- V3: multi-cruce remoto/local.
- V4: diagnostico hardware y opticas.
- V5: mapa interactivo.
- V6: sincronizacion visible.
- V7: selector manual/automatico desde regulador.
- V8.1: mapa Leaflet/OpenStreetMap operativo.
- V8.1.1: nombres editables y enlaces manuales.
- V8.2: editor de geometria, grupos luminosos, fases e incompatibilidades.
- V8.2.1: correccion de package.json para npm install.
- V8.2.2: correccion de movimiento de cruces y bloqueo de verdes incompatibles.
- V8.2.3: recupera paneles V7: trafico, ajustes, detectores, hardware, camaras, reglas, registro y comprobacion.
- V8.2.4: decision del cruce, modo remoto/local/manual, corredor completo y borrado total de cruces.
- V8.2.5: marcadores compactos basados en iconos de semaforos, peatones y tipos de grupo.
- V8.2.6: iconos limpios en minimapa y correccion de sincronizacion/verde simultaneo incompatible.
- V8.2.7: plantilla de via principal + giro compatible, con peatones y transversal en rojo.
- V8.2.8: editor libre de codigos S11/S12/S13 para grupos/cabezas semaforicas.
- V8.2.9: grupos de cabezas/maniobras G con miembros S; permite abrir solo parte del grupo.
- V8.3.0: separa maniobras/grupos de cabezas semaforicas y tipos S11/S12/S13 de opticas.
- V8.3.1: adopta convencion GV/GP para grupos operativos y subgrupos.
- V8.3.2: simplifica GV/GP eliminando lado A/B; la posicion la representan miniaturas y cabezas.
- V8.3.3: estados independientes por cabeza en cada fase.
- V8.3.4: sincronizacion independiente de programacion/adaptativo; GV/GP con IDs estables.
- V8.3.5: arranque seguro con pantalla de carga y diagnostico visible si falla React.

## Rama moderna F2-V8.3-M1

Las revisiones `R` son incrementales sobre `F2-V8.3-M1`. No son versiones mayores del producto: son cierres practicos de interfaz, navegacion, usuarios, proyectos y control.

- F2-V8.3-M1-R20: menu lateral funcional por secciones; Inicio queda como pantalla completa.
- F2-V8.3-M1-R21: usuarios/roles, acceso local por PIN, menu de sesion en cabecera y revision de botones sin accion.
- F2-V8.3-M1-R22: limpieza de cabecera, logo, textos y menu de usuario sobre mapa.
- F2-V8.3-M1-R23: proyectos/ciudades separados.
- F2-V8.3-M1-R24: permisos reales por rol.
- F2-V8.3-M1-R25: mejoras de Configuracion, Sistema y Eventos.

## Ramas auxiliares

- C: compacta para lienzo.
- P: prueba/prototipo.

## Notas

- No se renumeran carpetas antiguas.
- Si una carpeta historica no coincide exactamente con este roadmap, se mantiene como evidencia de trabajo anterior.
- Desde esta documentacion, el seguimiento correcto es: roadmap general para hitos grandes y roadmap R para revisiones practicas.

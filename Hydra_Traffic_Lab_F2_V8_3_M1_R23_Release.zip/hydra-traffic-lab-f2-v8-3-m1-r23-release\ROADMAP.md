# Roadmap Hydra Traffic Lab

Hydra Traffic Lab usa dos niveles de roadmap para no mezclar versiones grandes del producto con revisiones practicas de interfaz, organizacion y control.

## Roadmap general del producto

Estas versiones marcan avances grandes del sistema.

### V8.3 - Mapa de E/S DI/DO

- Mapa de entradas digitales DI para lazos, pulsadores, selector manual/auto y alarmas.
- Mapa de salidas digitales DO para opticas.
- Simulacion de modulo Advantech/PLC.
- Preparacion del puente entre simulador y maqueta/laboratorio.

### V8.4 - Configuraciones, JSON y plantillas

- Importar configuraciones JSON.
- Exportar configuraciones JSON.
- Varias configuraciones guardadas.
- Validacion avanzada de conflictos.
- Plantillas de cruce.

### V9 - Servicio local del regulador

- Servicio local para mini PC o nodo de cruce.
- Comunicacion MQTT/WebSocket.
- Lectura y escritura de E/S real de laboratorio.
- Separacion entre centro web y nodo local.

### V10 - Programa de escritorio

- Version de escritorio para Windows.
- Version de escritorio para Linux.
- Empaquetado como EXE, AppImage o paquete deb.

## Roadmap de revisiones R

Las revisiones R son mejoras incrementales sobre la rama moderna `F2-V8.3-M1`. Sirven para cerrar interfaz, organizacion, usuarios, proyectos y control antes de entrar en saltos mayores del roadmap general.

### R22 - Limpieza visual y capas

- Limpiar cabecera, logo y textos.
- Corregir menu de usuario por encima del mapa.
- Corregir modal de acceso por encima del mapa.
- Quitar iconos provisionales confusos.

### R23 - Proyectos y ciudades separados

- Separar proyectos por ciudad o entorno.
- Permitir que cada ciudad tenga cruces, corredores, eventos y configuracion propia.
- Mantener vista global para Superadministrador.
- Preparar seleccion/cambio de proyecto sin mezclar datos.

### R24 - Permisos reales por rol

- Aplicar permisos reales segun rol.
- Bloquear acciones no permitidas.
- Mostrar motivo claro si una accion requiere permisos.
- Diferenciar consulta, operacion, mantenimiento, ingenieria y administracion.

### R25 - Configuracion, Sistema y Eventos

- Mejorar la seccion Configuracion.
- Mejorar la seccion Sistema.
- Mejorar la seccion Eventos.
- Ordenar diagnosticos, registros, avisos y acciones administrativas.

## Regla de versionado

- `V` indica version grande o hito tecnico del producto.
- `R` indica revision practica sobre la rama moderna actual.
- No se renumeran carpetas antiguas; desde ahora se documenta la intencion para seguir correctamente.

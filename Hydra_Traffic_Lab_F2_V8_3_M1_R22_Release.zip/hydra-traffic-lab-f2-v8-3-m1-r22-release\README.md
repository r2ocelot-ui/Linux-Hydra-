# Hydra Traffic Lab F2-V8.3-M1-R2A-R2-R2-R1 Release

Versión oficial que cierra las pérdidas detectadas entre V7 y V8.

## Novedades F2-V8.3-M1-R2A-R2-R2-R1

- Panel **Decisión del cruce**.
- Selector operativo claro:
  - Automático remoto
  - Automático local
  - Manual persona
  - Avería local
- Panel **Corredor seleccionado** completo:
  - usar 4 cruces
  - usar 5 cruces
  - ordenar por mapa
  - aplicar onda verde
- Sincronización comparando el **grupo principal** de cada cruce.
- Comprobación del sistema más estricta.
- Se permite eliminar el último cruce. El mapa puede quedar vacío y luego puedes añadir otro.
- Mantiene F2-V8.3-M1-R2A-R2-R2-R1: tráfico, ajustes, detectores, cámaras, hardware, reglas, registro y comprobación.

## Ejecutar

```powershell
npm install
npm run dev
```

Proyecto educativo/de laboratorio. No conectar a infraestructura real.


## Novedades F2-V8.3-M1-R2A-R2-R2-R1

- Marcadores del mapa rediseñados en formato compacto.
- Se sustituyen los recuadros grandes por iconos:
  - 🚗 vehículos
  - 🚶 peatones
  - 🚌 bus
  - 🚲 bici
  - ↰ giro protegido
- Cada grupo luminoso muestra un punto de color según su estado:
  - verde
  - ámbar
  - rojo
- El marcador también indica:
  - ID del cruce,
  - orden de corredor,
  - tipo de geometría,
  - modo operativo,
  - salud hardware.
- La información completa sigue disponible al seleccionar el cruce y en el popup.


## Corrección F2-V8.3-M1-R2A-R2-R2-R1

- Marcadores del minimapa convertidos a iconos operativos pequeños, no tarjetas.
- Los iconos muestran semáforos/peatones/bus/bici/giro con punto de color.
- Se refuerza la lógica de incompatibilidades: en cruces normales, V1/V2 quedan incompatibles.
- En pasos peatonales se permite V1+V2 juntos porque representan ambos sentidos de la misma vía.
- La sincronización se compara por grupo principal de corredor, no solo por etapa global.
- La comprobación del sistema detecta verde vehicular simultáneo N/S y E/O.


## Novedades F2-V8.3-M1-R2A-R2-R2-R1

- Nueva geometría: **Vía principal + giro compatible**.
- Grupos por defecto:
  - V1: vía principal continúa.
  - G1: giro desde vía principal.
  - V2: vía lateral/transversal cerrada.
  - P1/P2: peatones.
- Fases por defecto:
  - F1: principal + giro en verde; transversal y peatones en rojo.
  - F2: transversal/acceso en verde; principal, giro y peatones en rojo.
  - F3: peatones en verde; todos los vehículos y giros en rojo.
- La seguridad permite V1 + G1 juntos, pero bloquea V1/G1 junto con V2 o peatones.
- Se añade un ejemplo tipo “Av. Europa · principal + giro”.


## Novedades F2-V8.3-M1-R2A-R2-R2-R1

- Los grupos luminosos ya no tienen que llamarse V1/P1/G1.
- Se puede editar el código de cada grupo/cabeza semafórica:
  - S11
  - S12
  - S13
  - cualquier otro código alfanumérico.
- Botones rápidos:
  - + S vehículo
  - + S peatón
  - + S giro
- Al cambiar el código de un grupo, se actualizan automáticamente:
  - fases,
  - grupos en verde,
  - incompatibilidades.
- Si añades un S como peatón, usa ópticas peatonales rojo/verde.
- Si añades un S como vehículo o giro, usa rojo/ámbar/verde.


## Novedades F2-V8.3-M1-R2A-R2-R2-R1

- Añadidos **grupos de cabezas / maniobras**.
- Ahora un grupo lógico `G1` puede contener varias cabezas semafóricas `S11`, `S12`, etc.
- Una fase puede abrir:
  - todo el grupo,
  - o solo una parte del grupo.
- Nueva plantilla: **Av. Europa giro**.
  - `S11`: vehículos norte hacia vía principal.
  - `S12`: vehículos sur vía principal.
  - `S13`: giro desde norte.
  - `S14`: entrada desde vía derecha/lateral.
  - `S21/S22`: peatones.
- Ejemplo de fase:
  - `S11 + S13` en verde.
  - `S12`, `S14`, `S21`, `S22` en rojo.
- Esto permite representar casos donde la vía principal continúa parcialmente y se habilita un giro, mientras otros accesos quedan cerrados.


## Novedades F2-V8.3-M1-R2A-R2-R2-R1

Cambio de modelo importante:

- `S11`, `S12`, `S13` pasan a tratarse como **tipos/configuraciones de cabeza semafórica**, no como simples grupos.
- Se separan:
  - **maniobra/grupo operativo**: qué movimiento se abre o se cierra.
  - **cabeza semafórica**: elemento físico/lógico que muestra luces.
  - **tipo S**: composición de ópticas de esa cabeza.

Tipos incluidos:

- `S11`: una óptica, normalmente ámbar.
- `S12`: dos ópticas, normalmente doble ámbar.
- `S13_RAV`: rojo/ámbar/verde.
- `S13_RAA`: rojo/ámbar/ámbar.
- `PED_RG`: peatón rojo/verde.
- `ARROW_RAG`: flecha rojo/ámbar/verde.

Esto permite representar cruces donde una fase abre norte + giro, deja sur en rojo, deja la entrada derecha en rojo y mantiene peatones en rojo, sin que el programa mezcle conceptos.


## Novedades F2-V8.3-M1-R2A-R2-R2-R1

- Se fija la convención de grupos operativos:
  - `GV` = grupo vehículos.
  - `GP` = grupo peatones.
- Subgrupos recomendados:
  - `GV-A` = vehículos lado A / norte / principal.
  - `GV-B` = vehículos lado B / sur / opuesto.
  - `GV-G` = giro de vehículos.
  - `GV-L` = lateral / entrada secundaria.
  - `GV-A+G` = lado A + giro compatible.
  - `GP-A` = peatón lado A.
  - `GP-B` = peatón lado B.
- Botones nuevos:
  - `+ Grupo GV`
  - `+ Grupo GP`
  - `Aplicar GV/GP`
- La plantilla Av. Europa giro usa ya la nomenclatura GV/GP.
- Se mantiene la separación:
  - maniobra/grupo operativo: GV/GP.
  - cabeza semafórica: H11/H12/H13.
  - tipo de cabeza: S11/S12/S13.


## Ajuste F2-V8.3-M1-R2A-R2-R2-R1

- Se elimina la nomenclatura rígida `lado A / lado B`.
- `GV` queda como familia de grupos de vehículos.
- `GP` queda como familia de grupos peatonales.
- Subgrupos recomendados, pero editables:
  - `GV-Principal`
  - `GV-Giro`
  - `GV-Lateral`
  - `GP`
- La posición real no se fuerza en el nombre del grupo:
  - se ve mediante miniaturas semafóricas/peatonales en el mapa,
  - se define por la cabeza semafórica,
  - y se puede describir en el nombre editable de la cabeza.
- La plantilla Av. Europa giro se actualiza con esta nomenclatura limpia.


## Novedades F2-V8.3-M1-R2A-R2-R2-R1

- Norte, sur, este, oeste, giros y pasos peatonales dejan de depender de bloques rígidos.
- Cada cabeza semafórica puede tener un estado independiente por fase:
  - rojo,
  - verde,
  - ámbar,
  - doble ámbar,
  - peatón verde,
  - peatón rojo.
- Se añade editor de **estado por cabeza en cada fase**.
- Se añade preset: **Escenario maniobras independientes**.
- Ese preset permite casos como:
  - bajada vía principal en verde,
  - subida vía principal en rojo,
  - giro izquierda bajando en verde,
  - calle lateral en rojo,
  - peatones de vía principal en rojo,
  - peatones de lateral en verde,
  - aviso de precaución en doble ámbar.
- En otra fase:
  - vía principal cerrada/parcial,
  - calle lateral abierta,
  - paso lateral en rojo,
  - peatones de vía principal en verde,
  - maniobra anterior en ámbar o doble ámbar.
- El mapa debe tender a mostrar solo miniaturas/iconos; el detalle se configura en paneles.


## Corrección F2-V8.3-M1-R2A-R2-R2-R1

- La sincronización queda separada de la programación/adaptación:
  - si `Coordinación activa` está ON y el cruce está vinculado, el desfase se aplica aunque el plan sea fijo/local/no adaptativo.
  - el modo manual/persona sí aísla el cruce.
- En corredor coordinado se mantiene el ciclo base para evitar que la adaptación por demanda rompa la onda verde.
- La comparación de sincronización usa:
  - desfase previsto por offset,
  - error de sincronización,
  - no solo diferencia bruta de `localTick`.
- Los grupos GV/GP quedan estabilizados:
  - el código interno del grupo ya no se edita en caliente.
  - se puede editar el nombre operativo.
  - `Quitar` elimina solo ese grupo.
  - se sanitizan duplicados y miembros repetidos.


## Corrección F2-V8.3-M1-R2A-R2-R2-R1

- Añadida pantalla de carga visible en `index.html`.
- Añadido `RuntimeErrorBoundary` para que, si React falla, no quede una pantalla negra/azul vacía.
- Añadido mensaje de diagnóstico en pantalla con el error real.
- Añadido `console.info("Hydra Traffic Lab F2-V8.3-M1-R2A-R2-R2-R1 arrancando...")` para confirmar que el JS entra.
- No cambia la lógica semafórica de V8.3.4; es una release de arranque/diagnóstico.


## Reparación F2-V8.3-M1-R2A-R2-R2-R1

- Corrige el fallo de arranque:
  - `ReferenceError: applyGvGpConvention is not defined`.
- Se añade `applyGvGpConvention()` dentro de `GeometryEditor`.
- Se asegura `sanitizeControlGroups()` para limpiar duplicados GV/GP.
- Mantiene la pantalla de diagnóstico de V8.3.5.
- Nueva nomenclatura aplicada:
  - `R1` = reparación / fix.


## Mejora F2-V8.3-M1-R2A-R2-R2-R1

- Las fases configurables ahora se pueden gestionar sin rehacer el cruce.
- Añadido:
  - `+ Añadir fase`
  - `Duplicar fase`
  - `Vaciar fase`
  - `Quitar fase`
- Al quitar una fase:
  - no se elimina el cruce,
  - no se eliminan grupos luminosos,
  - no se eliminan cabezas semafóricas,
  - solo desaparece esa fase.
- Se añade limpieza interna de fases:
  - evita IDs duplicados,
  - evita grupos repetidos en una fase,
  - conserva outputs por cabeza.


## Reparación F2-V8.3-M1-R2A-R2-R2-R1

- Corrige `Vaciar fase` para que no queden outputs/cabezas en verde.
- En `Grupos en verde` se añade:
  - quitar un grupo concreto con chip `× grupo`,
  - `Quitar todos`.
- Al quitar un grupo del verde:
  - se elimina de `greenGroups`,
  - sus cabezas asociadas pasan a `red` o `ped_red`.
- Al añadir un grupo al verde:
  - sus cabezas asociadas pasan a `green` o `ped_green`.
- Evita que una cabeza conserve un verde por output manual después de quitar su grupo.


## Reparación F2-V8.3-M1-R2A-R2-R2-R1

- Corrige el botón de `Grupos en verde` dentro de cada fase `F1`, `F2`, etc.
- Ahora cada grupo funciona como interruptor:
  - `+ V1` añade el grupo al verde.
  - `✓ V1` lo quita del verde al volver a pulsarlo.
- Se mantiene la opción `Quitar todos los verdes`.
- Al quitar un grupo, las cabezas asociadas pasan a rojo o peatón rojo.
- Al añadir un grupo, las cabezas asociadas pasan a verde o peatón verde.


## Reparación F2-V8.3-M1-R2A-R2-R2-R1

- En `Fases configurables > Grupos en verde` se eliminan los chips/botones circulares extra.
- Ahora se limpia con `Limpiar grupos en verde`.
- Los botones de grupo siguen actuando como interruptor:
  - `+ V1` añade.
  - `✓ V1` quita.
- Se corrige la terminología:
  - `+ S vehículo`, `+ S peatón`, `+ S giro` pasan a `+ Maniobra vehículo`, `+ Maniobra peatón`, `+ Maniobra giro`.
- S11/S12/S13 quedan como tipos/configuraciones de cabeza semafórica:
  - S11 = cabeza de 1 óptica.
  - S12 = cabeza de 2 ópticas.
  - S13 = cabeza de 3 ópticas.
- Se aclara que S13 puede tener variantes:
  - S13 R/A/V = rojo, ámbar, verde.
  - S13 R/A/A = rojo, ámbar, ámbar.


## Reparación F2-V8.3-M1-R2A-R2-R2-R1

- Se eliminan los botones amarillos:
  - `+ Maniobra vehículo`
  - `+ Maniobra peatón`
  - `+ Maniobra giro`
- Quedan solo los botones necesarios:
  - `+ Vehículo`
  - `+ Peatón`
  - `+ Giro`
  - `+ Bus`
  - `+ Bici`
- Se añade selector `Maniobra que realiza` en cada grupo luminoso:
  - recto / continuidad,
  - giro izquierda,
  - giro derecha,
  - entrada lateral,
  - paso peatonal,
  - aviso / preaviso,
  - bus,
  - bici,
  - personalizada.
- S11/S12/S13 quedan reservados para cabezas semafóricas/ópticas:
  - S11 = 1 óptica,
  - S12 = 2 ópticas,
  - S13 = 3 ópticas.
- S13 puede ser:
  - rojo / ámbar / verde,
  - rojo / ámbar / ámbar.
- `Limpiar grupos en verde` queda siempre visible; si no hay grupos activos queda desactivado.


## Cambio F2-V8.3-M1-R2A-R2-R2-R1

- Se descarta la rama V8.3-M2 por resultar demasiado confusa.
- Base usada: V8.3-R5.
- Cambios aplicados:
  - `Editor de geometría...` pasa a `Configurador de Grupos y Maniobras`.
  - `Grupos luminosos` pasa a `Grupos del cruce`.
  - `Cabezas semafóricas y tipos S` pasa a `Cabezas semafóricas`.
  - Se eliminan los botones amarillos redundantes.
  - Se mantiene S11/S12/S13 solo como tipo de cabeza/ópticas.
  - Se evita reestructurar demasiado la interfaz para no romper lo que funcionaba.
- Esta versión es la nueva base recomendada para seguir iterando.


## Cambio F2-V8.3-M1-R2A-R2-R2-R1

- Implementa una interfaz tipo mockup solicitada.
- Panel superior: Configuración de Grupos con tarjetas G1/G2/G3 y grupo seleccionado.
- Panel inferior: Configuración de Maniobras filtrada por el grupo seleccionado.
- La configuración antigua queda en un desplegable avanzado para no perder fases, tiempos e incompatibilidades.
- Base usada: V8.3-C1.


## Cambio F2-V8.3-M1-R2A-R2-R2-R1

- En `Configuración de Maniobras`, las tarjetas nuevas pasan a usar prefijo `M`:
  - `M1`, `M2`, `M3`...
- Se deja de usar `H` en la interfaz principal porque `H` confundía con “hardware/head”.
- La nomenclatura queda:
  - `G` = grupo del cruce.
  - `M` = maniobra semafórica.
  - `S` = tipo/configuración de óptica.
- Ejemplo:
  - `G1` = grupo vía principal.
  - `M1` = maniobra recto principal.
  - `M2` = maniobra giro izquierda.
  - `S13 R/A/V` = tipo de óptica de 3 luces rojo/ámbar/verde.


## Prueba F2-V8.3-M1-R2A-R2-R2-R1

- El organigrama era solo explicativo; no se muestra en la interfaz.
- Se cambia el orden de la primera vista:
  1. Cabecera/resumen.
  2. Mapa operativo.
  3. Centro de control del regulador:
     - ajustes globales,
     - selector del regulador,
     - intervención rápida.
  4. Corredor seleccionado.
- El panel de edición detallada del cruce se baja junto a `Tráfico y demanda`.
- Base usada: V8.3-C3.


## Prueba F2-V8.3-M1-R2A-R2-R2-R1

- Añadido menú lateral izquierdo.
- Secciones visibles:
  - Vista general
  - Mapa del sistema
  - Cruces
  - Corredores
  - Escenarios
  - Informes
  - Eventos
  - Dispositivos
  - Cámaras
  - Configuración
  - Usuarios
  - Sistema
- Añadida tarjeta de estado del sistema.
- Licencia actualizada a `Hydra Company`.
- Base usada: V8.3-P1.


## Prueba F2-V8.3-M1-R2A-R2-R2-R1

- Compactado `Centro de control del regulador`.
- `Selector del regulador` e `Intervención rápida` ahora aparecen a la misma altura en dos recuadros paralelos.
- `Ajustes globales` queda a la izquierda.
- Objetivo: ganar espacio bajo el mapa y antes de `Corredor seleccionado`.
- Base usada: V8.3-P2.


## Prueba F2-V8.3-M1-R2A-R2-R2-R1

- Implementa la base visual elegida:
  - encabezado `Centro de Control - Hydra Traffic Lab`,
  - menú lateral izquierdo,
  - mapa central grande,
  - panel derecho de control,
  - eventos recientes bajo el mapa,
  - licencia `Hydra Company`.
- El panel derecho contiene:
  - ajustes globales,
  - selector del regulador,
  - intervención rápida,
  - corredor seleccionado,
  - acciones rápidas,
  - resumen del sistema.
- La primera imagen/organigrama queda solo como referencia de arquitectura.
- Base usada: V8.3-P3.


## Reparación de prueba F2-V8.3-M1-R2A-R2-R2

- Probada revisión estática de la P4.
- Corregido:
  - duplicado de `liveIssues`,
  - referencia errónea a `intersections` dentro de App,
  - botón `Añadir cruce` del panel derecho para que cree el cruce cerca del seleccionado,
  - botón `Iniciar` del panel derecho para que arranque/pare la simulación.
- Se mantiene la base visual P4:
  - menú izquierdo,
  - mapa central grande,
  - panel derecho de control,
  - eventos recientes abajo,
  - licencia Hydra Company.


## Reparación F2-V8.3-M1-R2A

- Se revisa la última versión visual P4.
- Se fijan versiones de dependencias para evitar fallos por `latest`.
- Se protege `Exportar JSON` ante bloqueo del portapapeles del navegador.
- Se protegen las acciones rápidas para evitar errores si una acción no está disponible.
- Se limpia la versión visible a `F2-V8.3-M1-R2A`.


## Reparación F2-V8.3-M1-R2A

- Corrige el error:
  - `ReferenceError: safeAction is not defined`
  - origen: `CorridorPanel`.
- Causa:
  - `safeAction` quedó usado fuera de `RightControlPanel`.
- Solución:
  - `safeAction()` pasa a ser helper global disponible para todos los paneles.
- Se mantiene la interfaz P4:
  - menú lateral,
  - mapa grande,
  - centro de control,
  - acciones rápidas,
  - resumen del sistema,
  - corredor seleccionado.


## Reparación F2-V8.3-M1-R2A

- Ajusta la interfaz a la imagen objetivo:
  - mapa grande arriba,
  - Centro de Control compacto debajo,
  - Corredor seleccionado después.
- `Acciones rápidas` queda dentro del Centro de Control:
  - Iniciar/Pausar,
  - Añadir cruce,
  - Unir cruces,
  - Optimizar onda,
  - Comprobar,
  - Eliminar,
  - Exportar JSON,
  - Reiniciar.
- Corrige el defecto visual de la imagen 2:
  - botones cortados,
  - bloque demasiado alto,
  - panel de control fuera de proporción.
- Base usada: V8.3-P4-R3, que ya arrancaba correctamente.


## Reparación visual F2-V8.3-M1-R2A

- Añade campana de notificaciones en la cabecera superior derecha.
- Añade acceso de usuario `Administrador` en cabecera.
- Mejora `Resumen del sistema` con estilo de tarjetas tipo mockup.
- Rediseña `Corredor seleccionado` con:
  - panel de selección/estado,
  - secuencia visual de cruces,
  - resumen del corredor a la derecha.
- Base usada: V8.3-P4-R4.


## Ajuste ligero F2-V8.3-M1-R2

- No se crea V8.3-P4-R6.
- Se mantiene base F2-V8.3-M1-R2.
- Cambio visual:
  - `Acciones rápidas` sube a la zona superior central.
  - `Selector del regulador` baja a la zona inferior central.
  - `Intervención rápida` se mantiene arriba a la derecha.
  - `Resumen del sistema` se mantiene abajo a la derecha.
- Nuevo orden:
  - Ajustes globales | Acciones rápidas | Intervención rápida
  - Ajustes globales | Selector regulador | Resumen del sistema


## F2-V8.3-M1-R2

Corrección sobre la idea R5B, partiendo de la base visual V8.3-P4-R5A.

Se corrige:
- `Corredor seleccionado` se mantiene como Corredor seleccionado; no se renombra a Cruce/Cruces seleccionados.
- `Control del cruce` conserva sus opciones y se reorganiza en lateral/horizontal para no crecer tanto hacia abajo.
- `Eventos recientes` pasa a ventana flotante con minimizar, maximizar y cerrar. La campana la vuelve a abrir.

Se mantiene:
- guardado automático local,
- carga del último proyecto,
- proyecto nuevo vacío si no hay guardado,
- puntos de restauración,
- restaurar último,
- guardar ahora,
- borrar guardado local,
- nuevo proyecto seguro,
- eliminar protegido,
- optimizar onda sin borrar nada.


## F2-V8.3-M1-R3

Base: F2-V8.3-M1-R2.

Cambios mínimos:
- `Corredor seleccionado` pasa a `Cruces seleccionados`.
- `Tráfico y demanda` pasa a `Demanda` para ganar espacio.
- En `Unir cruces manualmente`, los botones se colocan en columna:
  - Modo unir cruces
  - Cancelar
  - Borrar enlaces

No se toca:
- menú lateral,
- Centro de Control,
- cámaras,
- lazos,
- hardware,
- configuradores,
- guardado/restauración.


## F2-V8.3-M1-R3-R1

Base: F2-V8.3-M1-R3.

Reparación única:
- Si el proyecto está vacío o no hay cruce seleccionado, el panel `Sin cruce seleccionado` ahora permite:
  - `Añadir primer cruce`,
  - activar/desactivar `Modo añadir` para crear desde el mapa.

No se toca:
- menú lateral,
- Centro de Control,
- cámaras,
- lazos,
- hardware,
- configuradores,
- guardado/restauración,
- cambios visuales de R3.


## F2-V8.3-M1-R4

Base: F2-V8.3-M1-R3-R1.

Cambios solicitados:
- `Demanda` / `Tráfico y demanda` pasa a `Detectores`.
- `Unir cruces manualmente` se estrecha y mantiene los botones en columna.
- En fichas/paneles se prioriza el nombre visible del cruce frente a A/B/C.
- Donde se muestra una tarjeta de cruce, se añade tooltip nativo con el nombre completo cuando el texto se recorta.
- `ID técnico` queda tratado como referencia interna, no como título principal visible.

No se toca:
- menú lateral,
- Centro de Control,
- guardado/restauración,
- cámaras,
- lazos,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R4-R1

Base: F2-V8.3-M1-R4.

Correcciones:
- `Unir cruces manualmente` ahora usa una columna estrecha real para:
  - Modo unir cruces
  - Cancelar
  - Borrar enlaces
- Se eliminan restos visuales de `Demanda` y se sustituye por `Detectores`.
- `Cámaras del cruce` pasa a carrusel horizontal:
  - no hay cámaras por defecto en cruces nuevos,
  - botón para añadir cámara,
  - solo 3 cámaras visibles,
  - flechas izquierda/derecha para navegar.


## F2-V8.3-M1-R4-R2

Base: F2-V8.3-M1-R4-R1.

Corrección:
- No se renombra `Tráfico y demanda`.
- El panel vuelve a llamarse `Tráfico y demanda · nombre del cruce`.
- Se intercambia la posición:
  - `Detectores` sube al sitio donde estaba `Tráfico y demanda`.
  - `Tráfico y demanda` baja al sitio donde estaba `Detectores`.
  - `Control del cruce` y `Cámaras del cruce` mantienen su zona.
- Se mantiene el carrusel horizontal de cámaras de R4-R1.

No se toca:
- menú lateral,
- Centro de Control,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.

## F2-V8.3-M1-R21

Base: F2-V8.3-M1-R20.

Cambios:
- Añade usuarios/roles con matriz visual de permisos.
- Añade acceso local simulado por usuario y PIN.
- Hace funcional el botón superior derecho de usuario con menú de sesión.
- Corrige controles que quedaban como visuales sin acción directa.

No se toca:
- lógica semafórica,
- guardado/restauración,
- estructura visual de Control del cruce, Detectores, Tráfico y demanda ni Cámaras.


## F2-V8.3-M1-R4-R3

Base: F2-V8.3-M1-R4-R2.

Correcciones visuales:
- Las flechas de `Cámaras del cruce` están dentro del recuadro de cámaras.
- El carrusel de cámaras no ensancha el programa completo.
- Se mantienen 3 cámaras visibles como máximo.
- Los cruces no traen cámaras por defecto.
- `Detectores` queda arriba junto a `Control del cruce`.
- `Detectores` es un único recuadro con:
  - Norte/Sur arriba,
  - Este/Oeste abajo.
- `Tráfico y demanda` conserva su nombre y queda en el bloque inferior.

No se toca:
- menú lateral,
- Centro de Control,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R4-R3-R1

Base: F2-V8.3-M1-R4-R3.

Reparación única:
- Eliminar la barra de desplazamiento horizontal inferior global.
- Ajustar paneles internos para que no empujen el ancho total:
  - cámaras,
  - detectores,
  - filas de dos columnas,
  - paneles principales.

No se toca:
- menú lateral,
- Centro de Control,
- guardado/restauración,
- nombres de paneles,
- cámaras como carrusel,
- detectores apilados,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R4-R4

Base: F2-V8.3-M1-R4-R3-R1.

Cambio único: tarjetas de `Cámaras del cruce`.

Incluye:
- X pequeña en cada tarjeta de cámara.
- Confirmación antes de quitar cámara.
- Cola.
- Vehículos.
- Visibilidad en vez de Confianza.
- Estado claro:
  - Cámara operativa / Cámara con fallo.
  - Salida libre / Salida saturada.
- Máximo 3 cámaras visibles.
- Flechas dentro del recuadro.
- Sin cámaras por defecto.

No se toca:
- menú lateral,
- Centro de Control,
- guardado/restauración,
- Detectores,
- Tráfico y demanda,
- Control del cruce,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R4-R5

Base: F2-V8.3-M1-R4-R4.

Objetivo:
- Ajustar la visualización como la referencia enviada.
- Mantener todo dentro del ancho de la web.
- Evitar barra horizontal inferior global.

Distribución:
- Arriba: Detectores + Control del cruce.
- Abajo: Tráfico y demanda + Cámaras del cruce.

Cámaras:
- 3 tarjetas visibles máximo.
- Flechas dentro del recuadro.
- X por cámara.
- Confirmación al quitar.
- Cola, Vehículos, Visibilidad.
- Cámara operativa / Cámara con fallo.
- Salida libre / Salida saturada.

No se toca:
- menú lateral,
- Centro de Control,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R4-R5-R1

Base: F2-V8.3-M1-R4-R5.

Reparación única:
- El panel de detectores vuelve a titularse `Detectores · nombre del cruce`.
- El panel `Tráfico y demanda · nombre del cruce` conserva su nombre.

No se toca:
- menú lateral,
- Centro de Control,
- Control del cruce,
- Cámaras,
- Tráfico y demanda,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R4-R5-R2

Base: F2-V8.3-M1-R4-R5-R1.

Reparación única:
- `Control del cruce` ya no debe cortarse por la derecha.
- `Vista y cálculo` entra dentro del panel.
- Si no cabe en una sola línea, `Vista y cálculo` baja a la fila inferior dentro del mismo panel.
- Se evita que el panel genere barra horizontal global.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R4-R5-R3

Base: F2-V8.3-M1-R4-R5-R2.

Cambios:
- `Tráfico y demanda` pasa a visual tipo resumen:
  - Demanda actual.
  - Tráfico actual.
  - Plan de demanda activo.
  - Factor de ajuste.
  - Ajustes manuales compactos por dirección.
- `Cámaras del cruce` aumenta el tamaño del visor de cada cámara.
- Se mantiene máximo 3 cámaras visibles.
- Se mantienen flechas dentro del recuadro, X, confirmación, cola, vehículos y visibilidad.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Control del cruce,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R5

Versión consolidada para cerrar la cadena de reparaciones R4-R5.

Incluye:
- Detectores compacto y con título correcto.
- Control del cruce sin cortarse por la derecha.
- Vista y cálculo baja dentro del panel si no cabe.
- Tráfico y demanda con visual de resumen.
- Cámaras con visor grande, máximo 3 visibles, flechas internas, X y confirmación.
- Sin barra horizontal global.

No se toca:
- menú lateral,
- Centro de Control,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R6

Base: F2-V8.3-M1-R5.

Cambios:
- Detectores más compacto con separadores verticales internos.
- Detectores reduce su ancho para dar espacio a Control del cruce.
- Control del cruce mantiene Vista y cálculo dentro del panel.
- Cámaras con visor más grande, máximo 3 visibles y flechas internas.
- Tráfico y demanda conserva visual de resumen.

No se toca:
- menú lateral,
- Centro de Control,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R7

Base: F2-V8.3-M1-R6.

Reparación real del `Control del cruce`:
- Se usa la clase real `.crossing-control-wide-grid`.
- Fila superior:
  - Identificación.
  - Operación.
  - Unir cruces manualmente.
- Fila inferior:
  - Vista y cálculo a ancho completo.
- `Vista y cálculo` ya no compite por espacio con los otros tres bloques.
- `Referencia visible / A` se cambia por:
  - Nombre visible.
  - ID técnico.
- El ID técnico se genera desde el nombre:
  - `Cruce Lepanto` → `C-LEPANTO-01`.
  - `Lepanto con Jaén` → `C-LEPANTO-JAEN-01`.
  - `Lepanto 3` → `C-LEPANTO-03`.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R8

Base: F2-V8.3-M1-R7.

Cambios:
- `Vista y cálculo` vuelve a la derecha de `Unir cruces manualmente`.
- `Identificación` se compacta:
  - Nombre visible.
  - Geometría.
  - ID técnico.
  - Botón `?` con ventana informativa.
- ID técnico mejorado:
  - `Nuevo cruce A` → `C-A-01`.
  - `Lepanto` → `C-LEPANTO-01`.
  - `Lepanto con Jaén` → `C-LEPANTO-JAEN-01`.
- Si la pantalla no tiene ancho suficiente, `Vista y cálculo` baja debajo automáticamente.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R8-R1

Base: F2-V8.3-M1-R8.

Reparación:
- Corrige error React: `Objects are not valid as a React child`.
- La geometría ya no se pinta como objeto.
- Si `selected.geometry` es objeto, se muestra `geometryType`, `label`, `name` o `type`.
- Si no existe, se muestra `Intersección en X`.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R8-R2

Base: F2-V8.3-M1-R8-R1.

Reparación visual:
- El botón `?` de información pasa a la esquina superior derecha del recuadro `Identificación`.
- La ventana informativa del `?` aparece dentro del propio recuadro de Identificación.
- El bloque de identificación queda más limpio:
  - Nombre del cruce.
  - Geometría del cruce.
  - Nombre visible.
  - Geometría.
  - ID técnico.
- El texto explicativo ya no ocupa espacio fijo junto al ID.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R9

Base: F2-V8.3-M1-R8-R2.

Reparación:
- Se elimina la duplicación en Identificación.
- El recuadro Identificación queda solo con:
  - Nombre del cruce.
  - Geometría.
  - ID técnico.
  - Botón `?` arriba a la derecha.
- El botón `?` abre la información dentro del propio recuadro.
- Se limpian etiquetas antiguas como `Nombre operativo editable`, `Referencia visible` y bloques duplicados.
- Se mantiene `Vista y cálculo` a la derecha de `Unir cruces manualmente` si el ancho permite.

Versión limpia:
- El programa debe mostrar `F2-V8.3-M1-R9`, sin cadenas tipo `R8-R2-R2`.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R10

Base: F2-V8.3-M1-R9.

Cambio:
- `Nombre del cruce` es editable.
- `ID técnico` también es editable.
- Si no se edita el ID técnico, se genera automáticamente desde el nombre.
- Si se edita manualmente, se guarda como `technicalId`.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R11

Base: F2-V8.3-M1-R10.

Reparación real:
- El `ID del cruce` ahora edita el ID real del cruce, no solo un campo visual `technicalId`.
- Al cambiar el ID:
  - se actualiza el cruce,
  - se actualiza el cruce seleccionado,
  - se actualiza el corredor,
  - se actualizan enlaces manuales,
  - se actualiza el inicio de enlace manual si estaba activo.
- El `Nombre del cruce` sigue siendo editable.

Nota:
- El ID se aplica al salir del campo o pulsar Enter.
- Se normaliza a mayúsculas y guiones.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R12

Base: F2-V8.3-M1-R11.

Reparación:
- El campo `Nombre del cruce` ahora edita correctamente `selected.name`.
- Se corrige la llamada errónea:
  - antes: `onUpdateSelected(selected.id, { name: ... })`
  - ahora: `onUpdateSelected("name", ...)`
- `updateSelected` queda reforzado para aceptar también llamadas por ID + objeto.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R13

Base: F2-V8.3-M1-R12.

Reparación:
- El campo `ID del cruce` ya no puede quedar vacío.
- El ID debe conservar al menos 1 carácter válido.
- Solo se permiten letras, números y guiones.
- Si el usuario intenta borrar todo el ID, se mantiene el valor anterior.
- Al salir del campo, se normaliza de forma segura.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R14

Base: F2-V8.3-M1-R13.

Reparación:
- El campo `ID del cruce` puede quedarse vacío mientras se está editando.
- Esto permite borrar `A`, `1` o cualquier ID anterior y escribir desde cero.
- Al salir del campo:
  - si está vacío, se conserva el ID anterior,
  - si tiene texto válido, se aplica el nuevo ID.
- Al enfocar el campo, se selecciona todo el ID para facilitar la edición.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R15

Base: F2-V8.3-M1-R14.

Reparación:
- El `ID del cruce` permite mayúsculas y minúsculas.
- Ya no fuerza todo a mayúsculas.
- Sigue permitiendo números y guiones.
- Sigue pudiendo quedarse vacío mientras se edita.
- Si el campo queda vacío al salir, conserva el ID anterior.

Ejemplos válidos:
- `C-LEPANTO-01`
- `c-lepanto-01`
- `Cruce-Lepanto-01`
- `cruce-Lepanto-01`

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R16

Base: F2-V8.3-M1-R15.

Cambio:
- Añadido botón `?` contextual en cada recuadro de `Control del cruce`:
  - Identificación.
  - Operación.
  - Unir cruces manualmente.
  - Vista y cálculo.
- Cada `?` va en la esquina superior derecha del recuadro.
- Cada `?` abre una ventana informativa dentro del propio recuadro.
- El texto fijo de ayuda de `Unir cruces manualmente` se oculta para ganar espacio.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- mapa,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R17

Base: F2-V8.3-M1-R16.

Reparación visual:
- El botón `?` de `Unir cruces manualmente` queda del mismo tamaño que los demás `?`.
- La `X` de la ventana informativa de `Unir cruces manualmente` queda pequeña.
- La ventana informativa ya no hereda tamaños de botones del panel de unión.
- Se evita que reglas antiguas de `.link-card button` agranden botones internos de ayuda.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Tráfico y demanda,
- Cámaras,
- mapa,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R18

Base: F2-V8.3-M1-R17.

Cambio en `Tráfico y demanda`:
- `Plan de demanda activo` ahora es editable y guarda `demandPlan`.
- `Factor de ajuste` ahora es editable con número y slider.
- Plan y factor afectan a:
  - demanda visual,
  - tráfico actual estimado,
  - llegadas automáticas simuladas.
- Se añade botón `?` contextual en el panel.
- Los botones `+1`, `+5`, `-3` y `Peatón` se mantienen igual.

No se toca:
- Control del cruce,
- menú lateral,
- Centro de Control,
- Detectores,
- Cámaras,
- mapa,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.


## F2-V8.3-M1-R19

Base: F2-V8.3-M1-R18.

Cambios:
- `Tráfico y demanda`:
  - El botón `?` explica cada recuadro con más detalle.
  - Se aclara que `Plan de demanda activo` es el escenario base.
  - Se aclara que `Factor de ajuste` es un margen manual encima del plan.
  - Los botones `+1`, `+5`, `-3` se renombran como pruebas/simulación manual.
  - Se aclara que vehículos reales deberían venir de lazos/cámaras/IA y no de botones manuales.
  - `Peatón` se etiqueta como pulsador/simulación.

- `Identificación`:
  - `Geometría` pasa a ser editable.
  - Presets: X, I, T, Rotonda, Giro protegido y Personalizada.
  - El `?` de Identificación explica nombre, geometría e ID.

No se toca:
- menú lateral,
- Centro de Control,
- Detectores,
- Cámaras,
- mapa,
- guardado/restauración,
- hardware,
- configuradores,
- motor semafórico.

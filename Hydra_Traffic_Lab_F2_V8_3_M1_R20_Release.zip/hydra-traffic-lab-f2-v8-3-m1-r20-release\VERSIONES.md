# Versiones Hydra Traffic Lab

- V1: fases básicas.
- V2: lazos, cámara virtual y colas.
- V3: multi-cruce remoto/local.
- V4: diagnóstico hardware y ópticas.
- V5: mapa interactivo.
- V6: sincronización visible.
- V7: selector manual/automático desde regulador.
- V8.1: mapa Leaflet/OpenStreetMap operativo.
- V8.1.1: nombres editables y enlaces manuales.
- V8.2: editor de geometría, grupos luminosos, fases e incompatibilidades.

Ramas auxiliares:
- C = compacta para lienzo.
- P = prueba/prototipo.

- V8.2.1: corrección de package.json para npm install.

- V8.2.2: corrección de movimiento de cruces y bloqueo de verdes incompatibles.

- V8.2.3: recupera paneles V7: tráfico, ajustes, detectores, hardware, cámaras, reglas, registro y comprobación.

- V8.2.4: añade decisión del cruce, modo remoto/local/manual, corredor completo y permite borrar todos los cruces.

- V8.2.5: marcadores compactos con iconos de grupos luminosos para evitar recuadros grandes en el mapa.

- V8.2.6: iconos limpios en minimapa y corrección de sincronización/verde simultáneo incompatible.

- V8.2.7: añade plantilla de vía principal + giro compatible, con peatones y transversal en rojo.

- V8.2.8: editor libre de códigos S11/S12/S13 para grupos/cabezas semafóricas.

- V8.2.9: grupos de cabezas/maniobras G con miembros S; permite abrir solo parte del grupo, como S11+S13.

- V8.3.0: separa maniobras/grupos de cabezas semafóricas y tipos S11/S12/S13 de ópticas.

- V8.3.1: adopta convención GV/GP para grupos operativos y subgrupos GV-A, GV-B, GV-G, GV-L, GP-A, GP-B.

- V8.3.2: simplifica GV/GP eliminando lado A/B; la posición la representan las miniaturas y cabezas semafóricas.

- V8.3.3: estados independientes por cabeza en cada fase; permite N/S/E/O, giros, peatones y avisos ámbar/doble ámbar independientes.

- V8.3.4: sincronización independiente de programación/adaptativo; GV/GP con IDs estables y eliminación corregida.

- V8.3.5: arranque seguro con pantalla de carga y diagnóstico visible si falla React.

- V8.3-R1: reparación del error applyGvGpConvention no definido en GeometryEditor.

- V8.3-M1: mejora de fases configurables: añadir, duplicar, vaciar y quitar fases sin rehacer el cruce.

- V8.3-R2: reparación de Vaciar fase y gestión segura de Grupos en verde: quitar uno a uno o todos, sincronizando outputs por cabeza.

- V8.3-R3: reparación del toggle de Grupos en verde; pulsar un grupo activo ahora lo quita de la fase.

- V8.3-R4: elimina chips extra en Grupos en verde y corrige S11/S12/S13 como tipos de cabeza/ópticas, no como maniobras.

- V8.3-R5: elimina botones amarillos de maniobra, añade selector de tipo de maniobra y mantiene S11/S12/S13 como tipos de cabeza/ópticas.

- V8.3-C1: cambio de interfaz limpio sobre R5; se descarta M2 por ser confusa.

- V8.3-C2: interfaz tipo mockup con panel de grupos y panel de maniobras filtrado por grupo seleccionado.

- V8.3-C3: Configuración de Maniobras usa prefijo M en lugar de H; G=grupo, M=maniobra, S=óptica.

- V8.3-P1: prueba de orden de primera vista; mapa → centro de control del regulador → corredor seleccionado.

- V8.3-P2: añade menú lateral izquierdo y cambia licencia visible a Hydra Company.

- V8.3-P3: compacta Centro de control del regulador con Selector e Intervención rápida en dos recuadros paralelos.

- V8.3-P4: prueba visual con Centro de Control, mapa central grande, panel derecho y eventos recientes abajo.

- V8.3-P4-R1: reparación de prueba tras revisión: liveIssues duplicado, botón iniciar y añadir cruce del panel derecho.

- V8.3-P4-R2: reparación de P4/P4-R1: dependencias fijadas, export JSON seguro y acciones rápidas protegidas.

- V8.3-P4-R3: corrige ReferenceError safeAction is not defined en CorridorPanel.

- V8.3-P4-R4: aplica diseño tipo imagen objetivo y corrige desbordes del Centro de Control.

- V8.3-P4-R5: añade campana/usuario en cabecera, mejora Resumen del sistema y rediseña Corredor seleccionado.

- V8.3-P4-R5A: ajuste ligero; Acciones rápidas sube sobre Selector del regulador dentro del Centro de Control.

- F2-V8.3-M1-R2: corrige R5B: mantiene Corredor seleccionado, control del cruce horizontal y eventos flotantes.

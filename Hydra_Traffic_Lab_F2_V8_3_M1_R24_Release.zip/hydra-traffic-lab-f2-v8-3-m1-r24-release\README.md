# Hydra Traffic Lab F2-V8.3-M1-R24

Version de consolidacion de la rama moderna `F2-V8.3-M1`.

## Novedades R24

- Consolida la limpieza visual iniciada en R22/R23.
- Mantiene `Servicio activo`, mapa sin version en el titulo y ventanas sobre el mapa.
- Anade proyectos/ciudades separados.
- Muestra el proyecto activo en cabecera.
- Permite crear, cambiar y renombrar ciudad/proyecto.
- Cada proyecto conserva sus propios cruces, corredores, enlaces, eventos, configuracion y estado.
- Migra el guardado anterior `hydraTrafficLab.f2.project` a `Proyecto local` sin borrarlo.
- Superadministrador ve resumen global de proyectos.

## Ejecutar

```powershell
npm install
npm run dev -- --host 127.0.0.1 --port 5185
```

URL:

```text
http://127.0.0.1:5185/
```

Proyecto educativo/de laboratorio. No conectar a infraestructura real.
